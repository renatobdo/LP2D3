<?php

require "conexao.php";
require "Modelo/Produto.php";
require "Repositorio/ProdutoRepositorio.php";

$produtoRepositorio = new ProdutoRepositorio($conn);

$produtoRepositorio->deletar($_GET['id']);

    echo "Produto excluído com sucesso";
